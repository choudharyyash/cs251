
data = csvread('train.csv');
[row,col] = size(data);
data = data(2:row,:);
x_train = data(:,1);
y_train = data(:,2);

temp = ones(length(x_train),1);

x_1 = [temp,x_train];
w = rand(2,1);
hold on;
plot(x_train,y_train,'.c');
plot(x_train,w'*x_1','-r');
pause();
close;

w_direct = (inv(x_1'*x_1))*(x_1'*y_train);
hold on;
plot(x_train,y_train,'.c');
plot(x_train,w_direct'*x_1','-r');
pause();
close;

hold on;
plot(x_train,y_train,'.c');
for i=1:2
    for j= 1:10000
        x=data(j,1);
        y=data(j,2);
        x_ = [1,x]';
        w = w - (0.00000001*(w'*x_ - y)*x_);
        if rem(j,100)==0
            plot(x_train,w'*x_1');
        end

    end
end
pause();
close;

hold on;
plot(x_train,y_train,'.c');
plot(x_train,w'*x_1','-r');
pause();
close;

data = csvread('test.csv');
[row,col] = size(data);
data = data(2:row,:);
x_test = data(:,1);
y_test = data(:,2);
temp = ones(size(x_test));
x_test = [temp,x_test];
y_pred1 = x_test*w;
y_pred2 = x_test*w_direct;
y_er1 = y_pred1 - y_test;
y_er2 = y_pred2 - y_test;
y_rms1 = sqrt(mean(y_er1.^2))
y_rms2 = sqrt(mean(y_er2.^2))

#!/bin/bash
rm -f result.txt
for num_el in `cat $1`
do
    for num_th in `cat $2`
    do
        for i in {1..100}
        do
            echo "$num_el $num_th" `./App $num_el $num_th | cut -f 4 -d ' '` >> result.txt
        done
    done
done

#!/bin/bash
rm -f step_*.txt
avg=0
sqavg=0
cnt=0
while read i
do
    fields_1=`echo $i | cut -d ' ' -f1`
    fields_2=`echo $i | cut -d ' ' -f2`
    fields_3=`echo $i | cut -d ' ' -f3`
    if [[ $fields_2 -eq 1 ]]; then
        echo ${fields_1} ${fields_3} >> step_a1.txt
        avg=$((avg + fields_3))
        sq=$((fields_3*fields_3))
        sqavg=$((sqavg+sq))
        cnt=$((cnt+1))
        if [[ cnt -eq 100 ]]; then
            avg=$((avg/100))
            sqavg=$((sqavg/100))
            avgsq=$((avg*avg))
            var=$((sqavg-avgsq))
            echo ${fields_1} $avg $var >> step_bc1.txt
            a[$fields_1]=$avg
            avg=0
            sqavg=0
            cnt=0
        fi
    elif [[ ${fields_2} -eq 2 ]]; then
        echo ${fields_1} ${fields_3} >> step_a2.txt
        avg=$((avg + fields_3))
        sq=$((fields_3*fields_3))
        sqavg=$((sqavg+sq))
        cnt=$((cnt+1))
        if [[ cnt -eq 100 ]]; then
            avg=$((avg/100))
            sqavg=$((sqavg/100))
            avgsq=$((avg*avg))
            var=$((sqavg-avgsq))
            echo ${fields_1} $avg $var `bc -l <<< "$avg/${a[$fields_1]}"` >> step_bc2.txt
            avg=0
            sqavg=0
            cnt=0
        fi
    elif [[ ${fields_2} -eq 4 ]]; then
        echo ${fields_1} ${fields_3} >> step_a4.txt
        avg=$((avg + fields_3))
        sq=$((fields_3*fields_3))
        sqavg=$((sqavg+sq))
        cnt=$((cnt+1))
        if [[ cnt -eq 100 ]]; then
            avg=$((avg/100))
            sqavg=$((sqavg/100))
            avgsq=$((avg*avg))
            var=$((sqavg-avgsq))
            echo ${fields_1} $avg $var `bc -l <<< "$avg/${a[$fields_1]}"` >> step_bc4.txt
            avg=0
            sqavg=0
            cnt=0
        fi
    elif [[ ${fields_2} -eq 8 ]]; then
        echo ${fields_1} ${fields_3} >> step_a8.txt
        avg=$((avg + fields_3))
        sq=$((fields_3*fields_3))
        sqavg=$((sqavg+sq))
        cnt=$((cnt+1))
        if [[ cnt -eq 100 ]]; then
            avg=$((avg/100))
            sqavg=$((sqavg/100))
            avgsq=$((avg*avg))
            var=$((sqavg-avgsq))
            echo ${fields_1} $avg $var `bc -l <<< "$avg/${a[$fields_1]}"` >> step_bc8.txt
            avg=0
            sqavg=0
            cnt=0
        fi
    elif [[ ${fields_2} -eq 16 ]]; then
        echo ${fields_1} ${fields_3} >> step_a16.txt
        avg=$((avg + fields_3))
        sq=$((fields_3*fields_3))
        sqavg=$((sqavg+sq))
        cnt=$((cnt+1))
        if [[ cnt -eq 100 ]]; then
            avg=$((avg/100))
            sqavg=$((sqavg/100))
            avgsq=$((avg*avg))
            var=$((sqavg-avgsq))
            echo ${fields_1} $avg $var `bc -l <<< "$avg/${a[$fields_1]}"` >> step_bc16.txt
            avg=0
            sqavg=0
            cnt=0
        fi
    fi
done <$1

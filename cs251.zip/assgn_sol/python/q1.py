#!/usr/bin/python
import sys
from decimal import *
stri = sys.argv[1]
neg=1

stri=stri.upper()

if stri[0]=='-':
	neg=-1
	stri=stri[1:]
while stri[0]=='0':
	stri=stri[1:]

stlst=stri.split('.')

if len(stlst)>2 :
	print "Invalid Input"
	sys.exit(0)

if len(stlst)==2 :
	num=0
	num2=0.0
	
else :
	num=0

b_st=sys.argv[2]
b=-1
lst=['0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z']
blst=['2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','25','26','27','28','29','30','31','32','33','34','35','36']

for i in range(0,35):
	if b_st==blst[i]:
		b=i+2


if b==-1:
	print "Invalid Input"
	sys.exit(0)


temp=""
for letter in stlst[0]:
	temp = letter + temp


for ind in range(len(stlst[0])):
	flag=0
	for i in range(0,36):
		
		if temp[ind]==lst[i]:
			if b<=i:
				print "Invalid Input"
				sys.exit(0)
			num+=i*(b**ind)
			flag=1
	if flag==0:
		print "Invalid Input"
		sys.exit(0)
num*=neg
num_st=str(num)
ans=num_st
if len(stlst)==2 :
	temp=stlst[1]
	for ind in range(len(stlst[1])):
		flag=0
		for i in range(0,36):
			if temp[ind]==lst[i]:
				if b<=i:
					print "Invalid Input"
					sys.exit(0)
				num2+=(i*(b**(-(ind+1))))
				flag=1
		if flag==0:
			print "Invalid Input"
			sys.exit(0)
	num2_st=str(num2)
	num2_st=num2_st[2:]
	ans=num_st+'.'+num2_st

print ans



#ifndef __COMMON_H_
#define __COMMON_H_
      #define CD 10
extern int do_math(void);
extern int do_io(void);
extern int do_graphics(void);
#endif

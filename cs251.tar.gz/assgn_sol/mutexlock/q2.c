#include<stdio.h>
#include<stdlib.h>
#include<fcntl.h>
#include<pthread.h>

pthread_mutex_t lock;
double bal[11100]={0.0};
struct transac{

    int tran_type;
    double amnt;
    int accn1;
    int accn2;
};
static struct transac* datptr;

void* execu(void* arg)
{
    struct transac *cptr;
    struct transac *endptr = (struct transac*)arg;

    while(1){
         pthread_mutex_lock(&lock);
         if(datptr >= endptr){
               pthread_mutex_unlock(&lock);
               break;
         }
         cptr = datptr;
         datptr++;

         pthread_mutex_unlock(&lock);
         int type=cptr->tran_type;
         if(type==1)
         {
             pthread_mutex_lock(&lock);
             bal[cptr->accn1]+=(0.99*cptr->amnt);
             pthread_mutex_unlock(&lock);
         }
         else if(type==2)
         {
             pthread_mutex_lock(&lock);
             bal[cptr->accn1]-=(1.01*cptr->amnt);
             pthread_mutex_unlock(&lock);
         }
         else if(type==3)
         {
             pthread_mutex_lock(&lock);
             bal[cptr->accn1]+=(0.071*bal[cptr->accn1]);
             pthread_mutex_unlock(&lock);
         }
         else
         {
             pthread_mutex_lock(&lock);
             bal[cptr->accn1]-=(1.01*cptr->amnt);
             bal[cptr->accn2]+=(0.99*cptr->amnt);
             pthread_mutex_unlock(&lock);
         }
    }
    pthread_exit(NULL);
}

int main(int argc, char **argv)
{

     if(argc != 5){
         printf("Usage: %s <fileneme>\n", argv[0]);
         exit(-1);
     }

     FILE *facc;
     FILE *ftxn;

     facc=fopen(argv[1],"r");

     int temp1;
     double temp2;
     for(int i=0;i<10000;i++)
     {
         fscanf(facc,"%d %lf",&temp1,&temp2);
         bal[temp1]=temp2;

     }


     ftxn=fopen(argv[2],"r");
     int nthr=atoi(argv[4]);
     int ntxn=atoi(argv[3]);
     int txn_no,txn_type,acc1,acc2;
     double txnam;
     pthread_t threads[nthr];


     struct transac *txns;
     txns = malloc(ntxn * sizeof(struct transac));

     for(int i=0;i<ntxn;i++)
     {
         fscanf(ftxn,"%d %d %lf %d %d",&txn_no,&txn_type,&txnam,&acc1,&acc2);
         struct transac *temptxn = txns + i;
         temptxn->tran_type=txn_type;
         temptxn->amnt=txnam;
         temptxn->accn1=acc1;
         temptxn->accn2=acc2;
     }
     datptr=txns;
     struct transac* eptr=txns+ntxn;

     for(int i=0;i<nthr;i++)
     {
         if(pthread_create(&threads[i], NULL, execu, eptr) != 0){
              perror("pthread_create");
              exit(-1);
        }
     }

     for(int i=0; i<nthr;i++)
            pthread_join(threads[i], NULL);
     for(int i=0;i<11100;i++)
     {
         if(bal[i]!=0)
         {
             printf("%d %.2lf\n",i,bal[i]);
         }
     }
     free(txns);
     fclose(facc);
     fclose(ftxn);
}

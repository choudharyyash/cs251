#step-1

len_data <- 50000
ran_vec = rexp(len_data,0.2)
temp <- sort(ran_vec)
plot(seq(1,len_data,1),temp)

#step-2

par_data <- matrix(ran_vec,nrow=500)

#step-3

mean_data <- apply(par_data,1,mean)
stdd_data <- apply(par_data,1,sd)
for(i in 1:5){
    pdf_data <- rep(0, 100)
    for(j in 1:100){
        val=round(par_data[i,j], 0);
        if(val <= 100){
            pdf_data[val] = pdf_data[val] + 1/100;
        }
    }
    xcols <- c(0:99)
    plot(xcols, pdf_data, "l", xlab="x", ylab="PDF")
    cdf_data <- rep(0, 100)
    cdf_data[1] <- pdf_data[1]
    for(i in 2:100){
        cdf_data[i] = cdf_data[i-1] + pdf_data[i]
    }
    plot(xcols, cdf_data, "o", col="blue", xlab="x", ylab="CDF");

    prnt <- c(mean_data[i],stdd_data[i])
    print(prnt)
}

#step-4

tab <- table(round(mean_data,1))
plot(tab, "h", xlab="Value", ylab="Frequency")
pdf_mean <- rep(0, 100);
for(i in 1:500){
    val=round(mean_data[i], 0);
    if(val <= 100){
       pdf_mean[val] = pdf_mean[val] + 1/500;
    }
}
xcols <- c(0:99)
plot(xcols, pdf_mean, "l", xlab="x", ylab="PDF")
cdf_mean <- rep(0, 100)
cdf_mean[1] <- pdf_mean[1]
for(i in 2:100){
    cdf_mean[i] = cdf_mean[i-1] + pdf_mean[i]
}
plot(xcols, cdf_mean, "o", col="blue", xlab="x", ylab="CDF");

#step-5

prnt <- c(mean(mean_data),sd(mean_data))
print(prnt)

#step-6

prnt <- c(mean(ran_vec),sd(ran_vec))
print(prnt)

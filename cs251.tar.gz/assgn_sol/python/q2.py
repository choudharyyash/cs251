#!/usr/bin/python
import numpy as np
import matplotlib.pyplot as plt
import csv


flag=0
x=[]
y=[]
x1=[]

with open('train.csv', 'rb') as csvfile:
    fo = csv.reader(csvfile, delimiter=',')
    for row in fo:
        if(flag==0):
            flag=1
            continue
        x.append(float(row[0]))
        y.append(float(row[1]))
        x1.append(1)

x = np.array(x)
y = np.array(y)
x_t=x.transpose()
x_train = x.transpose()
y_train = y.transpose()
x1_train = np.array(x1)
x1_train = x1_train.transpose()

x_train=np.c_[x1_train,x_train]
w=np.random.rand(2,1)

w_t=w.transpose()

x_train_tr=x_train.transpose()
tempar=np.dot(w_t,x_train_tr)

f1=plt.figure(1)
plt.plot(x,tempar[0],'r')
plt.scatter(x,y)
f1.show()
w_direct=np.dot(np.dot(np.linalg.inv(np.dot(x_train_tr,x_train)),x_train_tr),y_train)
w_direct_tr=w_direct.transpose()
tempar=np.dot(w_direct_tr,x_train_tr)
fig2=plt.figure(2)
plt.scatter(x,y)
plt.plot(x,tempar,'r')
fig2.show()

for i in range(0,2):
    for j in range(0,10000):
        x__=np.random.rand(2,1)
        x__[0]=1
        x__[1]=x[j]
        w_t=w.transpose()
        w=w- (0.00000001*(np.dot(w_t,x__)-y_train[j])*x__)
        
        if j%100==0:
            w_t=w.transpose()
            tempar=np.dot(w_t,x_train_tr)
            fig3=plt.figure(3)
            plt.scatter(x,y)
            plt.plot(x,tempar[0])
            fig3.show()

w_t=w.transpose()
tempar=np.dot(w_t,x_train_tr)
fig4=plt.figure(4)
plt.scatter(x,y)
plt.plot(x,tempar[0],'r')
plt.show()
flag=0

x=[]
y=[]
x1=[]

with open('test.csv', 'rb') as csvfile:
    fo = csv.reader(csvfile, delimiter=',')
    for row in fo:
        if(flag==0):
            flag=1
            continue
        x.append(float(row[0]))
        y.append(float(row[1]))
        x1.append(1)

x = np.array(x)
y = np.array(y)
x_t=x.transpose()
x_test = x.transpose()
y_test = y.transpose()
x1_test = np.array(x1)
x1_test = x1_test.transpose()
x_test=np.c_[x1,x_test]

y_p1=np.dot(x_test,w)
y_p2=np.dot(x_test,w_direct)

y_p1_tr=y_p1.transpose()

print np.sqrt(((y_p1_tr[0]-y_test) **2).mean())
print np.sqrt(((y_p2-y_test) **2).mean())
#!/bin/bash
regex='\.c$'
calcu(){

	 if [ -d "$1" ]
	 then
	 	cd "$1"
     	for line in *
     	do
            calcu "$line"
     	done
     	cd ..   
     elif [[ $1 =~ $regex ]]
     then
     	ncom=`awk -f $current/q1.awk $1 | head -1`
        nstr=`awk -f $current/q1.awk $1 | tail -1`
		a=$((a+ncom))
		b=$((b+nstr))
	fi

}
current=`pwd`
a=0
b=0
calcu "$1"
echo "$b strings"
echo "$a lines of comments"